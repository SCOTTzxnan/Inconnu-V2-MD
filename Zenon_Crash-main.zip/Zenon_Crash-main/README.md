<h1 align="center"> ZENON CRASH </h1>
<p align="center">  
  
***
  
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=1BAFBAFF&center=true&width=910&height=100&lines=THANKS FOR CHOOSING ;ZENON +CRASH;WHATSAPP+BUG+BOT;CREATED+BY+TOXXIC+BOY;RELEASED+15-08-24" alt="Typing SVG" /></a>
  </p>
    <a href="https://ibb.co/4dZX3XG"><img src="https://i.ibb.co/6BRTLTx/thumb.jpg" alt="thumb" border="0"></a>
<p align="center">
<p align="center">
<a href="https://github.com/Toxic1239/Zenon_Crash"><img title="Author" src="https://img.shields.io/badge/ZenonCrash?style=for-the-badge&logo=github"></a>
<p align="center">
<a href="https://github.com/Toxic1239/followers"><img title="Followers" src="https://img.shields.io/github/followers/Toxic1239?color=blue&style=flat-square"></a>
<a href="https://github.com/Toxic1239/Zenon_Crash/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Toxic1239/Zenon_Crash-Star?color=red&style=flat-square"></a>
<a href="https://github.com/Toxic1239/Zenon_Crash/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Toxic1239/Zenon_Crash?color=green&style=flat-square"></a>
<a href="https://github.com/Toxic1239/Zenon_Crash/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Toxic1239/Zenon_Crash?label=Watchers&color=yellow&style=flat-square"></a>

### FIRST STAR AND FORK (IMPORTANT) 

1. Click on **[Fork](https://github.com/Toxic1239/Zenon_Crash/fork)** A must . Make sure to add a star 🌟 to encourage the developers.
### 2. GET SESSION ID HERE 

<a href='https://replit.com/@obidikechikadib/Toxic-Creds#main.sh' target="_blank"><img alt='PAIR CODE' src='https://img.shields.io/badge/Click here to get your Creds file-blue?style=for-the-badge&logo=opencv&logoColor=white'/></a> 

**DEPLOYMENT PROCESS**
### IF YOU WANNA DEPLOY ANYWHERE JUST ADD YOUR CREDS.JSON TO YOUR FORKED REPO**

### DEPLOY ON REPLIT
IF YOU DON'T HAVE A REPLIT ACCOUNT CREATE ONE AND DEPLOY 
    <br>
    <a href='https://replit.com/github/Toxic1239/Zenon_Crash' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Deploy-red?style=for-the-badge&logo=replit&logoColor=white'/></a>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
### DEPLOY ON CODESPACE 
1. Deploy. `Free`
JUST TYPE "NPM START" and the bot will start
 
    <br>
    <a href='https://github.com/codespaces' target="_blank"><img alt='Codespace' src='https://img.shields.io/badge/-Deploy-green?style=for-the-badge&logo=codespace&logoColor=white'/></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>    

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
# Termux Deployment
```
termux-setup-storage
```
```
apt update
```
```
apt upgrade
```
```
pkg update && pkg upgrade
```
```
pkg install bash
```
```
pkg install libwebp
```
```
pkg install git -y
```
```
pkg install nodejs -y
```
```
pkg install ffmpeg -y 
```
```
pkg install wget
```
```
pkg install yarn
```
```
git clone (copy and paste your forked repo link not mine to save changes your changes) 
```
```
cd Zenon_Crash
```
```
yarn install
```
```
npm start
```
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
- If you want Command For 24/7 (might no work) 
```js
npm i -g forever && forever index.js && forever save && forever logs
```
<br>

### REPORT ISSUES

if you're having any issues message me on
Owner: [Telegram](https://t.me/Toxxicn_bot) 

If the bot goes offline 
Just type cd and the bot name 
Then type npm start
It will come online

`Please Zenon_Crash is not for fun, don't use it to harm innocent people`


## Contributions

Contributions to Zenon_Crash are welcome! If you have ideas for new features, improvements, or bug fixes, feel free to open an issue or submit a pull request. <br>

   thanks to these people ;

   **Xeon** who made the base bot <br>


## License

The WhatsApp Bot Zenon_Crash is released under the [MIT License](https://opensource.org/licenses/MIT).

Enjoy the diverse features of the WhatsApp Bot Toxxic Md to enhance your conversations and make your WhatsApp experience more interesting!

## Developers:

-TOXXIC MD
